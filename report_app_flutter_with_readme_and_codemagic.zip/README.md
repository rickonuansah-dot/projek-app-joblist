# Report App Flutter

A simple Flutter app for daily engineering activity reports with photo, description, auto time & location, and export to Excel.

## Features
- Capture photo and activity details
- Auto-fill date, time, location
- View reports by day/week/month
- Export reports to Excel (.xlsx) with embedded photos

## Build Instructions
1. Install Flutter SDK
2. Run `flutter pub get`
3. Run `flutter build apk --release`
4. APK output: `build/app/outputs/flutter-apk/app-release.apk`

## Cloud Build (Codemagic)
This project includes a `codemagic.yaml` file for automated cloud build.
